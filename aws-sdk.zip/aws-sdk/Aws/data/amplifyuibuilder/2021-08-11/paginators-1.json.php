<?php
// This file was auto-generated from sdk-root/src/data/amplifyuibuilder/2021-08-11/paginators-1.json
return [ 'pagination' => [ 'ListComponents' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'entities', ], 'ListThemes' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'entities', ], ],];
